﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Devices.Gpio;
using System.Threading.Tasks;
using Windows.Devices.Spi;
using Windows.Devices.Enumeration;
using System.Diagnostics;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace IoT_01
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private GpioController gpio;
        private GpioPin sensor;
        byte[] readBuffer = new byte[3];
        byte[] writeBuffer = new byte[3] { 0x06, 0x00, 0x00 };

        private SpiDevice spi;

        private DispatcherTimer timer;

        private void Timer_Tick(object sender, object e)
        {
            spi.TransferFullDuplex(writeBuffer, readBuffer);
            int result = readBuffer[1] & 0x07;
            result <<= 8;
            result += readBuffer[2];
            result >>= 1;
            textblock01.Text = result.ToString();
        }

        public MainPage()
        {
            this.InitializeComponent();

        }

        protected async override void OnNavigatedTo(NavigationEventArgs e)
        {
            await StartSPI();
            main();
            base.OnNavigatedTo(e);
        }

        public void main()
        {
            
            GetValue();

        }

        public async void GetValue()
        {
            int result;
            while (true)
            {
                spi.TransferFullDuplex(writeBuffer, readBuffer);
                result = readBuffer[1] & 0x07;
                result <<= 8;
                result += readBuffer[2];
                result >>= 1;
                textblock01.Text = result.ToString();
                await Task.Delay(1000);
            }
        }

        private async Task StartSPI()
        {
            try
            {
                var settings = new SpiConnectionSettings(0);
                settings.ClockFrequency = 5000000;
                settings.Mode = SpiMode.Mode0;

                string spiAqs = SpiDevice.GetDeviceSelector("SPI0");
                var deviceInfo = await DeviceInformation.FindAllAsync(spiAqs);
                spi = await SpiDevice.FromIdAsync(deviceInfo[0].Id, settings);
            }
            catch (Exception ex)
            {
                throw new Exception("SPI Initialization Failed", ex);
            }
        }

    }
}
