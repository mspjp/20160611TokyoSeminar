﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Devices.Gpio;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Threading;
using System.Collections.ObjectModel;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace IoT_05
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private GpioPin irPin;
        private const int irPinNum = 5;
        private DispatcherTimer globalTimer;
        private Stopwatch sw;
        private ObservableCollection<string> timeList;
        private long previous = 0;
        private ObservableCollection<GpioPinValue> boolList;
        private ObservableCollection<string> looptimeList;
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void Init()
        {
            var gpioCon = GpioController.GetDefault();
            timeList = new ObservableCollection<string>();
            boolList = new ObservableCollection<GpioPinValue>();
            looptimeList = new ObservableCollection<string>();
            sw = new Stopwatch();
            irPin = gpioCon.OpenPin(irPinNum);
            irPin.SetDriveMode(GpioPinDriveMode.Input);
            timeBox.DataContext = timeList;
            boolBox.DataContext = boolList;
            loopBox.DataContext = looptimeList;
            //irPin.ValueChanged += IrPin_ValueChanged;
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            Main();
            base.OnNavigatedTo(e);
        }

        public async void Main()
        {
            Init();
            loop();
        }

        private bool[] parity = new bool[8];
        public bool search(bool[] boollist, int num)
        {
            if (num > 0)
            {
                if (boollist[num] == parity[num])
                {
                    return search(boollist, --num);
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }
        }

        public async Task loop()
        {
            sw.Reset();
            var flag = true;
            while (flag)
            {
                var boollist = new bool[128];

                //boolList.Insert(0, irPin.Read().ToString());
                if (irPin.Read() == GpioPinValue.Low)
                {
                    sw.Start();
                    boolList.Add(GpioPinValue.Low);
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    boolList.Add(irPin.Read());
                    timeList.Add(sw.ElapsedMilliseconds.ToString());
                    flag = false;
                }
            }

        }

        /*private async void IrPin_ValueChanged(GpioPin sender, GpioPinValueChangedEventArgs args)
        {
            sw.Reset();
            sw.Start();
            await Task.Delay(int.Parse((30 - sw.ElapsedMilliseconds).ToString()));
            boolList.Add(sender.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            await Task.Delay(int.Parse((60 - sw.ElapsedMilliseconds).ToString()));
            boolList.Add(sender.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            await Task.Delay(int.Parse((90 - sw.ElapsedMilliseconds).ToString()));
            boolList.Add(sender.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            await Task.Delay(int.Parse((120 - sw.ElapsedMilliseconds).ToString()));
            boolList.Add(sender.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            await Task.Delay(int.Parse((150 - sw.ElapsedMilliseconds).ToString()));
            boolList.Add(sender.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            await Task.Delay(int.Parse((180 - sw.ElapsedMilliseconds).ToString()));
            boolList.Add(sender.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            await Task.Delay(int.Parse((210 - sw.ElapsedMilliseconds).ToString()));
            boolList.Add(sender.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            await Task.Delay(int.Parse((240 - sw.ElapsedMilliseconds).ToString()));
            boolList.Add(irPin.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            await Task.Delay(int.Parse((270 - sw.ElapsedMilliseconds).ToString()));
            boolList.Add(irPin.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            await Task.Delay(int.Parse((300 - sw.ElapsedMilliseconds).ToString()));
            boolList.Add(irPin.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
        }*/

        public async Task ReadIr()
        {
            boolList.Clear();
            timeList.Clear();
            await Task.Delay(500);
            sw.Start();

            /*boolList.Add(irPin.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            boolList.Add(irPin.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            boolList.Add(irPin.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            boolList.Add(irPin.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            boolList.Add(irPin.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            boolList.Add(irPin.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            boolList.Add(irPin.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            boolList.Add(irPin.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            boolList.Add(irPin.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            boolList.Add(irPin.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            boolList.Add(irPin.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            boolList.Add(irPin.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            boolList.Add(irPin.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            boolList.Add(irPin.Read().ToString());
            timeList.Add(sw.ElapsedMilliseconds.ToString());
            sw.Stop();
            sw.Reset();*/
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            await ReadIr();
        }
    }
}
