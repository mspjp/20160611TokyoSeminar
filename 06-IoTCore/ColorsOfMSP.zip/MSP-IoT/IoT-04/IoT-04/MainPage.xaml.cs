﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Devices.Gpio;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace IoT_04
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private GpioPin pin;
        public ObservableCollection<string> list { get; set; }
        public MainPage()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            var controller = GpioController.GetDefault();
            pin = controller.OpenPin(6);
            list = new ObservableCollection<string>();
            listBox.DataContext = list;
            main();
            base.OnNavigatedTo(e);
        }

        public async Task main()
        {
            var sw = new Stopwatch();
            sw.Start();
            while (true)
            {
                dataView.Text = pin.Read().ToString();
                list.Insert(0, (sw.ElapsedTicks / (Stopwatch.Frequency / (1000L * 1000L))).ToString()/*sw.ElapsedMilliseconds.ToString()*/);
                sw.Reset();
                await Task.Delay(1);
                sw.Start();
            }
        }
    }
}
