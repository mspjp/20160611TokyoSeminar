﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IoT_InitializeApp02.Models
{
    public class MyColor
    {
        public MyColor(string colorName, bool[] bools, char word)
        {
            this.colorName = colorName;
            this.colorData = bools;
            this.colorWord = word;
        }
        public string colorName { get; set; }
        public bool[] colorData { get; set; }
        public char colorWord { get; set; }
    }

    public class MyColors
    {
        public MyColor Red;
        public MyColor Cyan;
        public MyColor Yellow;
        public MyColor Green;
        public MyColor Blue;
        public MyColor Magenta;
        public MyColor White;

        public List<MyColor> myColorsEnumerable;

        public MyColors()
        {
            Red = new MyColor("Red", new bool[3] { true, false, false }, 'a');
            Yellow = new MyColor("Yellow", new bool[3] { true, true, false }, 'b');
            Cyan = new MyColor("Cyan", new bool[3] { false, true, true }, 'c');
            Green = new MyColor("Green", new bool[3] { false, true, false }, 'd');
            Blue = new MyColor("Blue", new bool[3] { false, false, true }, 'e');
            Magenta = new MyColor("Magenta", new bool[3] { true, false, true }, 'f');

            myColorsEnumerable = new List<MyColor>();
            myColorsEnumerable.Add(Red);
            myColorsEnumerable.Add(Yellow);
            myColorsEnumerable.Add(Cyan);
            myColorsEnumerable.Add(Green);
            myColorsEnumerable.Add(Blue);
            myColorsEnumerable.Add(Magenta);
        }
    }
}
