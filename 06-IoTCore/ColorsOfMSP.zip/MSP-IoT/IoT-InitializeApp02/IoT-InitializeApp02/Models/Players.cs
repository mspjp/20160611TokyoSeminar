﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IoT_InitializeApp02.Models
{
    public class Players
    {
        public ObservableCollection<Player> players { get; set; }

        public Players()
        {
            players = new ObservableCollection<Player>();
            players.Add(new Player("Player1","1"));
            players.Add(new Player("Player2","2"));
            players.Add(new Player("Player3","3"));
            players.Add(new Player("Player4","4"));
        }
    }

    public class Player
    {
        public Player(string viewString, string stickNum)
        {
            this.viewString = viewString;
            this.stickNum = stickNum;
        }
        public string viewString { get; set; }
        public string stickNum { get; set; }
    }
}
