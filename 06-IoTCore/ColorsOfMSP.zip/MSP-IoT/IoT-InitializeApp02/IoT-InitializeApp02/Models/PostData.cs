﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Media.Imaging;

namespace IoT_InitializeApp02.Models
{
    public class PostData
    {
        public string name { get; set; }
        public MyColor color { get; set; }
        public Player player { get; set; }
        public string gameId { get; set; }
        public Bitmap image { get; set; }
        public BitmapSource bmpSource { get; set; }


        public string COMPort { get; set; }

        public AddToSend url { get; set; }

        //public byte[] imageByte { get; set; }
        //public Windows.Storage.Streams.IBuffer imageBuffer { get; set; }
    }
}
