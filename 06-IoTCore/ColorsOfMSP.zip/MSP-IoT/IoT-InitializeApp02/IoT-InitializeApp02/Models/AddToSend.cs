﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IoT_InitializeApp02.Models
{
    public class AddToSend
    {
        public AddToSend(string url, string name)
        {
            this.address = url;
            this.name = name;
        }
        public string address { get; set; }
        public string name { get; set; }
    }

    public static class Adds
    {
        public static AddToSend Users = new AddToSend("http://mspjp-iot-test.azurewebsites.net/insert_user", "Users");
        public static AddToSend MSPs = new AddToSend("http://mspjp-iot-test.azurewebsites.net/insert_msp", "MSPs");
    }
}
