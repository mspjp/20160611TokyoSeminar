﻿using IoT_InitializeApp02.Models;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;
using System.Windows.Navigation;

namespace IoT_InitializeApp02.InitPages
{
    /// <summary>
    /// Page2.xaml の相互作用ロジック
    /// </summary>
    public partial class Page2 : Page
    {
        private MyColors colors;
        bool buttonLock;
        public PostData data;
        public Page2()
        {
            InitializeComponent();
            Init();
        }

        private void Init()
        {
            colors = new MyColors();
            colorGrid.DataContext = colors.myColorsEnumerable;
            playerSelect.DataContext = new Players();
            buttonLock = false;
        }

        private async void NextButtonClicked(object sender, MouseButtonEventArgs e)
        {
            if (!buttonLock)
            {
                buttonLock = true;
                var color = (MyColor)colorGrid.SelectedItem;
                var name = nameBox.Text;
                var player = (Player)playerSelect.SelectedItem;
                if (color == null || string.IsNullOrEmpty(name) || player == null)
                {
                    MessageBox.Show("すべての欄に入力してください。", "おや？何かがおかしいようです。");
                    buttonLock = false;
                }
                else
                {
                    data.color = color;
                    data.name = name;
                    data.player = player;
                    Storyboard sb = this.FindResource("NextPageAnimation") as Storyboard;
                    sb.Begin();
                    var p = new Page3();
                    p.data = data;
                    await Task.Delay(200);
                    NavigationService.Navigate(p);
                    //this.Frame.Navigate(typeof(InitPage02), data);
                }
            }
        }

        private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            var p = new Page1();
            p.data = data;
            NavigationService.Navigate(p);
        }
    }
}
