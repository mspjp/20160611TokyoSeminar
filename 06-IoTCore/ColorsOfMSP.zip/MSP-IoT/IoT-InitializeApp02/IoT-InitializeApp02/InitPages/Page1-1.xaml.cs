﻿using IoT_InitializeApp02.Models;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace IoT_InitializeApp02.InitPages
{
    /// <summary>
    /// Page1.xaml の相互作用ロジック
    /// </summary>
    public partial class Page1_1 : Page
    {
        public PostData data;
        public Page1_1()
        {
            InitializeComponent();
            this.Loaded += PageLoaded;
        }

        private async void PageLoaded(object sender, RoutedEventArgs e)
        {
            await Task.Delay(2800);//画面のフェードエフェクトのため
            var p = new Page2();
            p.data = data;
            NavigationService.Navigate(p);
        }


        /*private void NextButtonClicked(object sender, TouchEventArgs e)
        {
            NavigationService.Navigate(new Page2());
        }*/



    }
}
