﻿using IoT_InitializeApp02.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IoT_InitializeApp02.InitPages
{
    /// <summary>
    /// Page1.xaml の相互作用ロジック
    /// </summary>
    public partial class Page1 : Page
    {
        public PostData data;
        public Page1()
        {
            InitializeComponent();
        }

        /*private void NextButtonClicked(object sender, TouchEventArgs e)
        {
            NavigationService.Navigate(new Page2());
        }*/

        private async void NextButton_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (data == null)
            {
                MessageBox.Show("設定ページでArduinoのCOMポートを設定してください。", "Oops!");
            }
            else
            {
                Storyboard sb = this.FindResource("NextPageAnim") as Storyboard;
                sb.Begin();
                await Task.Delay(200);//画面のフェードエフェクトのため
                var p = new Page1_1();
                p.data = data;
                NavigationService.Navigate(p);
            }
        }

        private void MoveToSettingsPage(object sender, MouseButtonEventArgs e)
        {
            var p = new SettingsPages.Settings();
            p.data = data;
            NavigationService.Navigate(p);
        }
    }
}
