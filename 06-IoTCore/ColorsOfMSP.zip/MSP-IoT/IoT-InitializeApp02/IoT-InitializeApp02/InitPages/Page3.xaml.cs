﻿using IoT_InitializeApp02.Models;
using OpenCvSharp.Extensions;
using OpenCvSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Drawing;
using System.IO;
using System.Windows.Media.Animation;

namespace IoT_InitializeApp02.InitPages
{
    /// <summary>
    /// Page3.xaml の相互作用ロジック
    /// </summary>
    public partial class Page3 : Page
    {
        public PostData data;
        bool buttonLock;
        public Page3()
        {
            InitializeComponent();
            buttonLock = false;
            this.Loaded += Page3_Loaded;
        }

        private void Page3_Loaded(object sender, RoutedEventArgs e)
        {
            GetCapturePreview();
        }

        private WriteableBitmap wb;
        private async Task GetCapturePreview()
        {
            try
            {
                using (var capture = new CvCapture(1))
                {
                    wb = new WriteableBitmap(capture.FrameWidth, capture.FrameHeight, 96, 96, PixelFormats.Bgr24, null);
                    while (true)
                    {
                        var image = await QueryFrameAsync(capture);
                        if (image == null) break;
                        image.Flip(null, FlipMode.Y);
                        WriteableBitmapConverter.ToWriteableBitmap(image, wb);
                        imgResult.Source = wb;
                    }
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Error While Getting Cameras");
                GetCapturePreview();
            }
        }

        private System.Drawing.Bitmap BitmapFromWriteableBitmap(WriteableBitmap writeBmp)
        {
            System.Drawing.Bitmap bmp;
            using (MemoryStream outStream = new MemoryStream())
            {
                BitmapEncoder enc = new BmpBitmapEncoder();
                enc.Frames.Add(BitmapFrame.Create((BitmapSource)writeBmp));
                enc.Save(outStream);
                bmp = new System.Drawing.Bitmap(outStream);
            }
            return bmp;
        }

        private async Task<IplImage> QueryFrameAsync(CvCapture capture)
        {
            return await Task.Run(() =>
            {
                return capture.QueryFrame();
            });
        }

        private async void NextButtonClicked(object sender, MouseButtonEventArgs e)
        {
            if (!buttonLock)
            {
                buttonLock = true;
                data.image = BitmapFromWriteableBitmap(wb);
                Storyboard sb = this.FindResource("NextPageAnimation") as Storyboard;
                sb.Begin();
                var p = new Page3_1();
                p.data = data;
                await Task.Delay(200);
                NavigationService.Navigate(p);
            }
        }
    }
}
