﻿using IoT_InitializeApp02.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.IO.Ports;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Linq;
using IoT_InitializeApp02.Utils;

namespace IoT_InitializeApp02.InitPages
{
    /// <summary>
    /// Page4.xaml の相互作用ロジック
    /// </summary>
    public partial class Page4 : Page
    {
        public PostData data;
        Storyboard story01;
        Arduino arduino;
        public Page4()
        {
            InitializeComponent();
            this.Loaded += Page4_Loaded;
        }

        private async void Page4_Loaded(object sender, RoutedEventArgs e)
        {
            story01 = this.FindResource("story01") as Storyboard;
            story01.Begin();
            await Task.Delay(2000);
            ChangeText(data.color.colorName + "チームとして登録します。");
            
            await Task.Delay(2000);
            ChangeText("サーバーに接続中です。");

            if (data.url == Adds.Users)
            {
                //var stickNum = await GetSticks();
                //data.stickNum = stickNum.ToString();
                await SendToServer();
                story01.Stop();
                Storyboard color = this.FindResource(data.color.colorName) as Storyboard;
                color.Begin();
                ChangeText("杖を初期化中です。");
                arduino = new Arduino(data.COMPort);
                await arduino.SendToStick(int.Parse(data.player.stickNum), data.color);
                arduino.StopSerial();
                await Task.Delay(1500);
            }
            else
            {
                await SendToServer();
            }

            ChangeText("登録が完了しました。");
            await Task.Delay(3000);
            var p = new Page1();
            p.data = data;
            NavigationService.Navigate(p);
        }

        private async Task<int> GetSticks()
        {
            HttpClient client = new HttpClient();
            HttpResponseMessage res;
            List<Stick> sticks;
            try
            {
                res = await client.GetAsync(new Uri("http://mspjp-iot-test.azurewebsites.net/initRpi"));
                string json = await res.Content.ReadAsStringAsync();

                sticks = MyJsonParser.Parse(json);

                if (sticks == null)
                {
                    return 1;
                }
                else
                {

                    var max = from stick in sticks
                              orderby int.Parse(stick.num) descending
                              select stick;

                    return int.Parse(max.First().num) + 1;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "5秒後に再試行します。", "Stick取得中のエラー");
                await Task.Delay(5000);
                return await GetSticks();
            }

        }



        private async void ChangeText(string text)
        {
            Storyboard fo = this.FindResource("FadeIn") as Storyboard;
            fo.Begin();
            await Task.Delay(160);
            NextButtonString.Text = text;
            Storyboard fi = this.FindResource("FadeOut") as Storyboard;
            fi.Begin();
        }

        public async Task SendToServer()
        {
            var client = new System.Net.Http.HttpClient();
            var content = new MultipartFormDataContent();
            var postData = new List<KeyValuePair<string, string>>();

            if (data.url == Adds.Users)
            {
                postData.Add(new KeyValuePair<string, string>("name", data.name));
                postData.Add(new KeyValuePair<string, string>("color", data.color.colorName));
                postData.Add(new KeyValuePair<string, string>("stick", data.player.stickNum));
                foreach (var keyValuePair in postData)
                {
                    content.Add(new StringContent(keyValuePair.Value), keyValuePair.Key);
                }

                var bmpContent = ImageToByte2(data.bmpSource);
                content.Add(new ByteArrayContent(bmpContent), "userpic", "userpic.bmp");
            }
            else
            {
                postData.Add(new KeyValuePair<string, string>("mspname", data.name));
                postData.Add(new KeyValuePair<string, string>("rpi", data.player.stickNum));
                foreach (var keyValuePair in postData)
                {
                    content.Add(new StringContent(keyValuePair.Value), keyValuePair.Key);
                }

                var bmpContent = ImageToByte2(data.bmpSource);
                content.Add(new ByteArrayContent(bmpContent), "userpic", "msp" + data.name + ".bmp");
            }

            try
            {
                var res = await client.PostAsync(new Uri(data.url.address), content);
                if (!res.IsSuccessStatusCode)
                {
                    throw new Exception("Access failed." + res.ReasonPhrase);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + " 5秒後にリトライします。", "Insertでエラーが発生しました。");
                await Task.Delay(5000);
                await SendToServer();
            }
        }

        public static byte[] ImageToByte2(BitmapSource bitmapSource)
        {
            JpegBitmapEncoder encoder = new JpegBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(bitmapSource));
            encoder.QualityLevel = 100;
            byte[] bit = new byte[0];
            using (MemoryStream stream = new MemoryStream())
            {
                encoder.Frames.Add(BitmapFrame.Create(bitmapSource));
                encoder.Save(stream);
                bit = stream.ToArray();
                stream.Close();
            }
            return bit;
        }
    }
}
