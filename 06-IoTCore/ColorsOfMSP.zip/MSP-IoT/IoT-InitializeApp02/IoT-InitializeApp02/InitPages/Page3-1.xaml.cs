﻿using IoT_InitializeApp02.Models;
using OpenCvSharp.Extensions;
using OpenCvSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Media.Animation;

namespace IoT_InitializeApp02.InitPages
{
    /// <summary>
    /// Page3.xaml の相互作用ロジック
    /// </summary>
    public partial class Page3_1 : Page
    {
        public PostData data;
        bool buttonLock;
        public Page3_1()
        {
            InitializeComponent();
            buttonLock = false;
            this.Loaded += Page3_Loaded;
        }

        private void Page3_Loaded(object sender, RoutedEventArgs e)
        {
            var bmpSource = loadBitmap(data.image);
            data.bmpSource = bmpSource;
            imgResult.Source = bmpSource;
        }
        private async void NextButtonClicked(object sender, MouseButtonEventArgs e)
        {
            if (!buttonLock)
            {
                buttonLock = true;
                Storyboard sb = this.FindResource("NextPageAnimation") as Storyboard;
                sb.Begin();
                var p = new Page4();
                p.data = data;
                await Task.Delay(200);
                NavigationService.Navigate(p);
            }
        }



        [DllImport("gdi32")]
        static extern int DeleteObject(IntPtr o);

        public static BitmapSource loadBitmap(System.Drawing.Bitmap source)
        {
            IntPtr ip = source.GetHbitmap();
            BitmapSource bs = null;
            try
            {
                bs = System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(ip,
                   IntPtr.Zero, Int32Rect.Empty,
                   System.Windows.Media.Imaging.BitmapSizeOptions.FromEmptyOptions());
            }
            finally
            {
                DeleteObject(ip);
            }

            return bs;
        }

        private async void PreviousButtonClicked(object sender, MouseButtonEventArgs e)
        {
            if (!buttonLock)
            {
                buttonLock = true;
                Storyboard sb = this.FindResource("NextPageAnimation") as Storyboard;
                sb.Begin();
                var p = new Page3();
                p.data = data;
                await Task.Delay(200);
                NavigationService.Navigate(p);
            }
        }
    }
}
