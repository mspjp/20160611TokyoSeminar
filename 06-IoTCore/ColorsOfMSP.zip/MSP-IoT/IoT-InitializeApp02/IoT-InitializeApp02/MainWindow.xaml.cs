﻿using System.Windows.Navigation;
using IoT_InitializeApp02.InitPages;
using IoT_InitializeApp02.Models;

namespace IoT_InitializeApp02
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : NavigationWindow
    {
        public MainWindow()
        {
            InitializeComponent();
            this.ShowsNavigationUI = false;
            Navigate(new Page1());
        }
    }
}
