﻿using IoT_InitializeApp02.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IoT_InitializeApp02.Utils
{
    public class MyJsonParser
    {
        public static List<Stick> Parse(string json)
        {
            var sticks = new List<Stick>(); 
            json = json.Replace("\"", "");
            json = json.Replace("[", "");
            json = json.Replace(" ", "");
            json = json.Replace("]", "");
            var data = json.Split(',');
            var datas = new List<string>(data);
            var number = datas.Count;
            if (number >= 2)
            {
                for (var i = 0; i < number; i++)
                {
                    if (i % 2 == 0)
                    {
                        sticks.Add(new Stick(data[i], data[i + 1]));
                    }
                }
                return sticks;
            }
            else
            {
                return null;
            }
        }
    }
}
