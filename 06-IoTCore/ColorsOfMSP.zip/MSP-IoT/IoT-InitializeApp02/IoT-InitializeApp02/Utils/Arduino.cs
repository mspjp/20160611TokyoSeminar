﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
using IoT_InitializeApp02.Models;

namespace IoT_InitializeApp02.Utils
{
    public class Arduino
    {
        SerialPort arduino;
        public Arduino(string port)
        {
            arduino = new SerialPort(port, 9600);
            try
            {
                arduino.Open();
            }
            catch (Exception ex)
            {
                throw new Exception("シリアル通信を開始できませんでした。", ex);
            }
        }

        public void StopSerial()
        {
            arduino.Close();
        }

        public async Task SendToStick(int stick, MyColor color)
        {
            List<char> send = new List<char>();
            char stickChar;

            switch (stick)
            {
                case 1:
                    stickChar = 'a';
                    break;
                case 2:
                    stickChar = 'b';
                    break;
                case 3:
                    stickChar = 'c';
                    break;
                case 4:
                    stickChar = 'd';
                    break;
                case 5:
                    stickChar = 'e';
                    break;
                case 6:
                    stickChar = 'f';
                    break;
                case 7:
                    stickChar = 'g';
                    break;
                case 8:
                    stickChar = 'h';
                    break;
                case 9:
                    stickChar = 'i';
                    break;
                case 10:
                    stickChar = 'j';
                    break;
                case 11:
                    stickChar = 'k';
                    break;
                case 12:
                    stickChar = 'l';
                    break;
                case 13:
                    stickChar = 'm';
                    break;
                case 14:
                    stickChar = 'n';
                    break;
                case 15:
                    stickChar = 'o';
                    break;
                default:
                    throw new Exception("StickNumberが範囲を超えています。");
            }

            send.Add(stickChar);
            send.Add(color.colorWord);
            await Task.Delay(6000);
            arduino.Write(send.ToArray(), 0, 2);
        }
    }
}
