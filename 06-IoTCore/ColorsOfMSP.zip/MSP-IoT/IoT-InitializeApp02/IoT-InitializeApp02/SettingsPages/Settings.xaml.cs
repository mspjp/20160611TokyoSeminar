﻿using IoT_InitializeApp02.InitPages;
using IoT_InitializeApp02.Models;
using System.Collections.ObjectModel;
using System.IO.Ports;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace IoT_InitializeApp02.SettingsPages
{
    /// <summary>
    /// Settings.xaml の相互作用ロジック
    /// </summary>
    public partial class Settings : Page
    {
        public PostData data;
        public ObservableCollection<AddToSend> urls;
        public Settings()
        {
            InitializeComponent();
            this.Loaded += Settings_Loaded;
        }

        private void Settings_Loaded(object sender, RoutedEventArgs e)
        {
            if (data == null)
            {
                data = new PostData();
                data.COMPort = "";
            }
            var ports = SerialPort.GetPortNames();
            foreach (var port in ports)
            {
                var item = new ListBoxItem();
                item.Content = port;
                if (port == data.COMPort)
                {
                    item.IsSelected = true;
                }
                PortListBox.Items.Add(port);
            }

            urls = new ObservableCollection<AddToSend>();
            urls.Add(Adds.Users);
            urls.Add(Adds.MSPs);

            SendToBox.DataContext = urls;
        }

        private void BackToInitializePage(object sender, RoutedEventArgs e)
        {
            string port = PortListBox.SelectedItem as string;
            AddToSend url = SendToBox.SelectedItem as AddToSend;
            //string stick = stickNumBox.Text.ToString();
            if (port != "" && url != null)
            {
                data.COMPort = port;
                data.url = url;
                //data.stickNum = stick;
                var p = new Page1();
                p.data = data;
                NavigationService.Navigate(p);
            }
        }
    }
}
