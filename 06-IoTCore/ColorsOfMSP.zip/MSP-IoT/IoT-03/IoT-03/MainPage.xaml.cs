﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

using Windows.Devices.Gpio;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;
using System.Collections.ObjectModel;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace IoT_03
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        GpioController controller;
        GpioPin ledPin;
        ObservableCollection<long> lists;
        public MainPage()
        {
            this.InitializeComponent();
            lists = new ObservableCollection<long>();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            microView.DataContext = lists;
            controller = GpioController.GetDefault();
            ledPin = controller.OpenPin(6);
            ledPin.SetDriveMode(GpioPinDriveMode.Output);
            ledPin.Write(GpioPinValue.Low);
            Main();
            base.OnNavigatedTo(e);
        }

        public async Task Main()
        {
            var sw = new Stopwatch();
            sw.Start();
            ledPin.Write(GpioPinValue.High);
            lists.Insert(0, sw.ElapsedMilliseconds /*sw.ElapsedTicks / (Stopwatch.Frequency / (1000L * 1000L))*/);
            //ledPin.Write(GpioPinValue.Low);
            lists.Insert(0, sw.ElapsedMilliseconds /*sw.ElapsedTicks / (Stopwatch.Frequency / (1000L * 1000L))*/);
            sw.Stop();
            //ループじゃなくてそのまま実行したときの秒数カウント見てみたいよね。
            /*while (true)
            {
                ledPin.Write(GpioPinValue.High);
                await Task.Delay(100);
                ledPin.Write(GpioPinValue.Low);
                await Task.Delay(100);
                lists.Insert(0, sw.ElapsedTicks / (Stopwatch.Frequency / (1000L * 1000L)));
                sw.Reset();
                sw.Start();
            }*/
        }
    }
}
