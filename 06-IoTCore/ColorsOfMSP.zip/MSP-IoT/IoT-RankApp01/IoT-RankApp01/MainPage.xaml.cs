﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Web.Http;
using Newtonsoft.Json;
using IoT_RankApp01.Models;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using Windows.Web.Http.Filters;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace IoT_RankApp01
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private RankInitModel users;
        public Rank rank;
        public DiffResults diffResults;
        public MainPage()
        {
            this.InitializeComponent();
        }

        protected async override void OnNavigatedTo(NavigationEventArgs e)
        {
            Init();
            DebugTextBlock.Text = "Loading...";
            await InitOnline();
            var tmp = CreateRank();
            var i = 1;
            foreach (var item in tmp)
            {
                item.number = i;
                rank.rank.Add(item);
                i++;
            }
            DebugTextBlock.Text = "Loaded!";
            base.OnNavigatedTo(e);
        }

        private void Init()
        {
            rank = new Rank();
            RankListView.DataContext = rank.rank;
        }

        private ObservableCollection<RankItem> CreateRank()
        {
            var tmp = new List<RankItem>();
            foreach (var user in users.UserInit)
            {
                var userPoint = diffResults.DiffResult.Where(x => x.name == user.name).Count();
                tmp.Add(new RankItem(user.picture, user.name, userPoint));
            }
            return new ObservableCollection<RankItem>(tmp.OrderByDescending(x => x.point).ToList());
        }
        private async Task InitOnline()
        {
            var filter = new HttpBaseProtocolFilter();
            filter.CacheControl.ReadBehavior = Windows.Web.Http.Filters.HttpCacheReadBehavior.MostRecent;
            filter.CacheControl.WriteBehavior = Windows.Web.Http.Filters.HttpCacheWriteBehavior.NoCache;
            HttpClient client = new HttpClient(filter);
            try
            {
                var res = await client.GetAsync(new Uri("http://mspjp-iot-test.azurewebsites.net/init_players"));
                var json = JsonConvert.DeserializeObject<RankInitModel>(res.Content.ToString());
                users = json;
                res = await client.GetAsync(new Uri("http://mspjp-iot-test.azurewebsites.net/fetch_points"));
                var pointJson = JsonConvert.DeserializeObject<DiffResults>(res.Content.ToString());
                diffResults = pointJson;
            }
            catch (Exception ex)
            {
                var message = new MessageDialog(ex.Message, "Error");
                await message.ShowAsync();
            }
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            DebugTextBlock.Text = "Loading...";
            await InitOnline();
            var tmp = CreateRank();
            rank.rank.Clear();
            var i = 1;
            foreach (var item in tmp)
            {
                item.number = i;
                rank.rank.Add(item);
                i++;
            }
            DebugTextBlock.Text = "Loaded!";
        }
    }
}
