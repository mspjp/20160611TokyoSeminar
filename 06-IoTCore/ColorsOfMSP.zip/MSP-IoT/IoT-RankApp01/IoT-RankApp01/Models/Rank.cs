﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IoT_RankApp01.Models
{
    public class Rank
    {

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }
        private ObservableCollection<RankItem> _rank;
        public ObservableCollection<RankItem> rank
        {
            get
            {
                return _rank;
            }
            set
            {
                _rank = value;
                OnPropertyChanged("rank");
            }
        }

        public Rank()
        {
            _rank = new ObservableCollection<RankItem>();
        }
    }

    public class RankItem
    {
        public int number { get; set; }
        public string photoUrl { get; set; }
        public string userName { get; set; }
        public int point { get; set; }
        public RankItem(string photoUrl, string userName, int point)
        {
            this.photoUrl = photoUrl;
            this.userName = userName;
            this.point = point;
        }

    }
}
