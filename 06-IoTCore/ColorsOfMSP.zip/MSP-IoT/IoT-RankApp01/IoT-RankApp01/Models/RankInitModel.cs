﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IoT_RankApp01.Models
{
    public class MSPInit
    {
        public string RowKey { get; set; }
        public string name { get; set; }
        public string picture { get; set; }
    }

    public class UserInit
    {
        public string RowKey { get; set; }
        public string color { get; set; }
        public string name { get; set; }
        public string picture { get; set; }
    }

    public class RankInitModel
    {
        public List<MSPInit> MSPInit { get; set; }
        public List<UserInit> UserInit { get; set; }
    }
}
