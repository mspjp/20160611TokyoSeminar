﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IoT_RankApp01.Models
{
    public class DiffResult
    {
        public int RowKey { get; set; }
        public string color { get; set; }
        public string mspname { get; set; }
        public string name { get; set; }
    }

    public class DiffResults
    {
        public List<DiffResult> DiffResult { get; set; }
    }
}
