﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using IoT_06.Models;
using Windows.Web.Http;
using Windows.Web.Http.Filters;
using IoT_06.Utils;
using Windows.UI.Xaml;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace IoT_06
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        static readonly int[] led01pinNums = new int[3] { 13, 6, 5 };//LED01のピン番号
        static readonly int[] led02pinNums = new int[3] { 16, 12, 4 };//LD02のピン番号
        static readonly int[] irSensorPinNums = new int[4] { 18, 23, 24, 25 };//irSensor(Arduino)のピン番号（下位ビットから順番）

        private bool getFlag;
        private MyColors colors;
        private IrSensor sensor;
        private TempDataStorage storage;

        private const int starTime = 3000;//撃たれて、無敵になる時間。

        private Blinker blinker;

        private DispatcherTimer initTimer;//定期的（1分間隔）にInitOnlineするためのtimer
        private const int initMilliseconds = 30000;

        public MainPage()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            Init();
            Reset();
            base.OnNavigatedTo(e);
        }

        private async void Init()
        {
            ColorLED[] leds = new ColorLED[2];
            leds[0] = new ColorLED(led01pinNums);
            leds[1] = new ColorLED(led02pinNums);
            blinker = new Blinker(leds);

            colors = new MyColors();
            sensor = new IrSensor(irSensorPinNums);
            storage = new TempDataStorage();

            RaspiNumBox.Text = RasPiData.number.ToString();

            await InitOnline();

            //定期的にInitOnlineを実行
            initTimer = new DispatcherTimer();
            initTimer.Interval = TimeSpan.FromMilliseconds(initMilliseconds);
            initTimer.Tick += InitTimer_Tick;
            initTimer.Start();
        }

        private async void InitTimer_Tick(object sender, object e)
        {
            await InitOnline();
        }

        private void Reset()
        {
            getFlag = false;
            GetLoop();
        }

        private async Task InitOnline()
        {
            try
            {
                var reloaded = await storage.GetAttenderData();
                if (reloaded)
                {
                    blinker.FirstBlink();
                }
                var number = storage.sticks.Count;
                for (var i = 0; i < number; i++)
                {
                    debugBox2.Text += (storage.sticks[i].num + ":" + storage.sticks[i].color + "\n");
                }
            }
            catch (Exception ex)
            {
                blinker.ErrorBlink(colors.Red);
                getFlag = true;
                debugBox.Text = ex.Message;
            }
        }

        private async Task GetLoop()
        {
            var innerGetFlag = true;
            int returnValue = 0;
            while (innerGetFlag)
            {
                returnValue = sensor.CheckNum();
                if (returnValue != 0)
                {
                    innerGetFlag = false;
                    getFlag = true;
                    debugBox2.Text = returnValue.ToString();
                    break;
                }
                await Task.Delay(50);
            }

            ChangeHitColor(returnValue);

            await Task.Delay(starTime);//色が変えられない（このときイルミネーションしたいよね。
            Reset();
        }

        private void ChangeHitColor(int returnValue)
        {
            var stickColors = from stick in storage.sticks
                              where int.Parse(stick.num) == returnValue
                              select stick;

            if (stickColors.Count() != 0)
            {
                var stickColor = stickColors.First();
                var returnColors = from colorData in colors.myColorsEnumerable
                                   where colorData.colorName == stickColor.color
                                   select colorData;

                if (returnColors.Count() != 0)
                {
                    var returnColor = returnColors.First();
                    blinker.ChangeColor(returnColor);
                    SendStick(stickColor);
                }
                else
                {
                    blinker.ErrorBlink(colors.White);
                }
            }
            else
            {
                blinker.ErrorBlink(colors.White);
            }
        }

        private async Task SendStick(Stick stick)
        {
            var client = new HttpClient();
            var content = new HttpMultipartFormDataContent();

            var stickNum = new HttpStringContent(stick.num);
            var raspiNum = new HttpStringContent(RasPiData.number.ToString());

            content.Add(stickNum, "stick");
            content.Add(raspiNum, "rpi");
            HttpResponseMessage res;
            try
            {
                res = await client.PostAsync(new Uri("http://mspjp-iot-test.azurewebsites.net/from_rpi"), content);
                if (!res.IsSuccessStatusCode)
                {
                    blinker.ErrorBlink(colors.Yellow);
                }
            }
            catch (Exception ex)
            {
                blinker.ErrorBlink(colors.Yellow);
                debugBox.Text = ex.Message;
            }
        }

        private async void ResetButtonClicked(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            await InitOnline();
            Reset();
        }
    }
}