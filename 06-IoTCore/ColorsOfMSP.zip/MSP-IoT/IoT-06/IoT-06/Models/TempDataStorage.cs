﻿using IoT_06.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Web.Http;
using Windows.Web.Http.Filters;

namespace IoT_06.Models
{
    public class TempDataStorage
    {
        public List<Stick> sticks { get; set; }
        public string oldJson { get; set; }
        public TempDataStorage()
        {
            sticks = new List<Stick>();
        }

        public async Task<bool> GetAttenderData()
        {
            var filter = new HttpBaseProtocolFilter();
            filter.CacheControl.ReadBehavior = Windows.Web.Http.Filters.HttpCacheReadBehavior.MostRecent;
            filter.CacheControl.WriteBehavior = Windows.Web.Http.Filters.HttpCacheWriteBehavior.NoCache;
            HttpClient client = new HttpClient(filter);
            HttpResponseMessage res;
            try
            {
                res = await client.GetAsync(new Uri("http://mspjp-iot-test.azurewebsites.net/initRpi"));

                var json = res.Content.ToString();
                if (json != oldJson)
                {
                    sticks = MyJsonParser.Parse(res.Content.ToString());
                    oldJson = json;
                    return true;
                }
                else
                {
                    return false;
                }
                /*storage.sticks.Add(new Stick("5", "Blue"));
                storage.sticks.Add(new Stick("12", "Blue"));
                storage.sticks.Add(new Stick("2", "Purple"));
                storage.sticks.Add(new Stick("3", "Green"));
                storage.sticks.Add(new Stick("4", "Yellow"));*/
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
