﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IoT_06.Models
{
    public class Stick
    {
        public string num { get; set; }
        public string color { get; set; }
        public Stick(string num, string color)
        {
            this.num = num;
            this.color = color;
        }
    }
}
