﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IoT_06.Models
{
    public static class RasPiData
    {
        public static readonly int number = 1;
    }
}
