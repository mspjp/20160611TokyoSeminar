﻿using IoT_06.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IoT_06.Utils
{
    public class Blinker
    {
        ColorLED led01, led02;
        MyColors colors;
        MyColor currentColor;//切り替えエフェクトで利用する
        MyColor previousColor;
        bool cancel;//タスクを取り消す
        bool isRunning;//今現在タスクが走っているか

        /// <summary>
        /// 
        /// </summary>
        /// <param name="leds">leds number must be two</param>
        public Blinker(ColorLED[] leds)
        {
            led01 = leds[0];
            led02 = leds[1];
            colors = new MyColors();
            currentColor = colors.White;
            previousColor = colors.White;
        }

        /********************タスクのはじめとおわりで呼び出す********************/
        private async Task StartTask()
        {
            if (isRunning)
            {
                cancel = true;
                while (isRunning)
                {
                    await Task.Delay(50);
                }
                cancel = false;
            }
            isRunning = true;
        }

        private void FinishTask()
        {
            isRunning = false;
        }

        /*********************************************************************/

        public async Task FirstBlink()
        {
            await StartTask();

            led01.ChangeColor(colors.Magenta);

            await Task.Delay(100);
            led01.ChangeColor(colors.Magenta);
            led02.ChangeColor(colors.Magenta);

            await Task.Delay(100);
            led01.ChangeColor(colors.Red);
            led02.ChangeColor(colors.Magenta);

            await Task.Delay(100);
            led01.ChangeColor(colors.Red);
            led02.ChangeColor(colors.Red);

            await Task.Delay(100);
            led01.ChangeColor(colors.Cyan);
            led02.ChangeColor(colors.Red);

            await Task.Delay(100);
            led01.ChangeColor(colors.Cyan);
            led02.ChangeColor(colors.Cyan);

            await Task.Delay(100);
            led01.ChangeColor(colors.Yellow);
            led02.ChangeColor(colors.Cyan);

            await Task.Delay(100);
            led01.ChangeColor(colors.Yellow);
            led02.ChangeColor(colors.Yellow);

            await Task.Delay(100);
            led01.ChangeColor(colors.Green);
            led02.ChangeColor(colors.Yellow);

            await Task.Delay(100);
            led01.ChangeColor(colors.Green);
            led02.ChangeColor(colors.Green);

            await Task.Delay(100);
            led01.ChangeColor(colors.Blue);
            led02.ChangeColor(colors.Green);

            await Task.Delay(100);
            led01.ChangeColor(colors.Blue);
            led02.ChangeColor(colors.Blue);

            await Task.Delay(100);
            led01.ChangeColor(colors.Magenta);
            led02.ChangeColor(colors.Blue);

            await Task.Delay(100);
            led01.ChangeColor(colors.Magenta);
            led02.ChangeColor(colors.Magenta);

            await Task.Delay(100);
            led01.Dark();
            led02.ChangeColor(colors.Magenta);

            await Task.Delay(100);
            led02.Dark();

            await Task.Delay(200);
            led01.ChangeColor(colors.White);
            led02.ChangeColor(colors.White);

            FinishTask();
        }

        public async Task ErrorBlink(MyColor color)
        {
            await StartTask();

            for (var i = 0; i < 10; i++)
            {
                led01.ChangeColor(color);
                led02.ChangeColor(color);
                await Task.Delay(50);
                led01.Dark();
                led02.Dark();
                await Task.Delay(50);
                if (cancel)
                {
                    isRunning = false;
                    return;
                }
            }
            led01.ChangeColor(colors.White);
            led02.ChangeColor(colors.White);

            FinishTask();
        }

        public async Task ChangeColor(MyColor color)
        {
            await StartTask();
            previousColor = currentColor;
            currentColor = color;
            var delay = 5;

            if (previousColor == currentColor)//同じ色に当てられたときは白と追いかけっこする
            {
                previousColor = colors.White;
            }

            while (delay < 500)
            {
                if (cancel)
                {
                    isRunning = false;
                    return;
                }
                led01.ChangeColor(previousColor);
                await Task.Delay(delay);
                led02.ChangeColor(previousColor);
                await Task.Delay(delay);
                led01.ChangeColor(currentColor);
                await Task.Delay(delay);
                led02.ChangeColor(currentColor);
                await Task.Delay(delay);
                delay *= 2;
            }
            FinishTask();
        }
    }
}
