﻿using IoT_06.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IoT_06.Utils
{
    public class MyJsonParser
    {
        public static List<Stick> Parse(string json)
        {
            List<Stick> sticks = new List<Stick>();
            json = json.Replace("\"", "");
            json = json.Replace("[", "");
            json = json.Replace(" ", "");
            json = json.Replace("]", "");
            var data = json.Split(',');
            var number = data.Count();
            for (var i = 0; i < number; i++)
            {
                if (i % 2 == 0)
                {
                    sticks.Add(new Stick(data[i], data[i + 1]));
                }
            }

            return sticks;
        }
    }
}
