﻿using System;
using System.Collections.Generic;
using System.Text;
using Windows.Networking.Proximity;

namespace Common.Helpers
{
    public class NFCHelper
    {
        ProximityDevice device;
        public NFCHelper()
        {
            device = ProximityDevice.GetDefault();
            if (device != null)
            {
                device.DeviceArrived += ProximityDeviceArrived;
                device.DeviceDeparted += ProximityDeviceDeparted;

                device.SubscribeForMessage("Windows.SampleNFC", messageReceived);
            }
        }

        private void ProximityDeviceDeparted(ProximityDevice sender)
        {
            System.Diagnostics.Debug.WriteLine("ProximityDeviceDeparted");
        }

        private void ProximityDeviceArrived(ProximityDevice sender)
        {
            var message = new MessageDialog("","");
        }

        private void messageReceived(Windows.Networking.Proximity.ProximityDevice device, Windows.Networking.Proximity.ProximityMessage message)
        {
            System.Diagnostics.Debug.WriteLine(message.DataAsString);
        }

    }
}
