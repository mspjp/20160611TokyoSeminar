﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage.Streams;
using Windows.UI.Xaml.Controls;

namespace RasPiApp.Models
{
    public class VoiceData
    {
        public IBuffer VoiceBuffer { get; set; }
        public string VoiceText { get; set; }
        public int TagNumber { get; set; }

        public VoiceData(string VoiceText, int TagNumber, IBuffer VoiceBuffer)
        {
            this.VoiceBuffer = VoiceBuffer;
            this.TagNumber = TagNumber;
            this.VoiceBuffer = VoiceBuffer;
        }

        public void Play()
        {
            MediaElement mysong = new MediaElement();
            // Read the stream into the buffer

            mysong.SetSource(this.VoiceBuffer.AsStream().AsRandomAccessStream(), "audio/x-wav");
            mysong.Play();
        }
    }
}
