﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage.Streams;

namespace RasPiApp.Models
{
    public static class TmpData
    {
        public static ObservableCollection<VoiceData> VoiceDataCollection { get; set; }
        public static ServerResponseJson ServerData { get; set; }

        public static SystemStates SystemState { get; set; }
    }
}
