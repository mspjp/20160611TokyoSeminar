﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RasPiApp.Models
{
    public class Tag
    {
        public string text { get; set; }
        public int nfc_id { get; set; }
    }

    public class ServerResponseJson
    {
        public string last_updated { get; set; }
        public List<Tag> tags { get; set; }
    }
}
