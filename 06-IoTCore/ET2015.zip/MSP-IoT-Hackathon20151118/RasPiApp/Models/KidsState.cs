﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RasPiApp.Models
{
    public class SystemStates
    {
        public SystemStates()
        {
            //初期状態
            this.DollState = DollStates.Initializing;
            this.KidsState = KidsStates.NotFound;
            this.Posture = Postures.Move;
        }

        public enum DollStates { Initializing, Initialized, Waiting, Moving, Staying }
        public enum KidsStates { NotFound, Found, Playing, Ignoring }
        public enum Postures { Put, Move }

        public DateTime ModifiedTimeOfDoll { get; set; }
        public DateTime ModifiedTimeOfPosture { get; set; }
        private DollStates _DollState;
        public DollStates DollState
        {
            get { return this._DollState; }
            set
            {
                this.ModifiedTimeOfDoll = DateTime.Now;
                this._DollState = value;
            }
        }

        private Postures _Posture;
        public Postures Posture
        {
            get { return this._Posture; }
            set
            {
                this.ModifiedTimeOfPosture = DateTime.Now;
                this._Posture = value;
            }
        }
        public KidsStates KidsState { get; set; }
    }
}
