﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Web.Http;
using OxfordTTS;
using Windows.UI.Popups;
using System.Threading;
using Windows.Storage.Streams;
using System.Threading.Tasks;
using Windows.Devices.Enumeration;
using Windows.Devices.SerialCommunication;
using RasPiApp.Utils;
using RasPiApp.Models;
using Newtonsoft.Json;

// 空白ページのアイテム テンプレートについては、http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409 を参照してください

namespace RasPiApp
{
    /// <summary>
    /// それ自体で使用できる空白ページまたはフレーム内に移動できる空白ページ。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            TmpData.VoiceDataCollection = new System.Collections.ObjectModel.ObservableCollection<VoiceData>();
            TmpData.ServerData = new ServerResponseJson();
            TmpData.SystemState = new SystemStates();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            MiningSensors();
            //DownloadVoiceData();
        }

        public async Task DownloadVoiceData()
        {
            try
            {
                while (true)
                {
                    await CheckServer();
                    await Task.Delay(600000);
                }
            }
            catch (Exception ex)
            {
                var message = new MessageDialog("CheckServer内のエラー：" + ex.Message, "おや？なにかがおかしいようです。");
                //await message.ShowAsync();
                voiceminingstate.Text = ex.Message;
                await Task.Delay(5000);
                await DownloadVoiceData();
            }
        }

        public async Task MiningSensors()
        {
            try
            {
                var serial = new SerialClient();
                while (true)
                {
                    await serial.CaptureSensors((x) =>
                    {
                        var data = JsonConvert.DeserializeObject<SensorDataJsonObject>(x);
                        var sum = Math.Abs(float.Parse(data.Gyro.x)) + Math.Abs(float.Parse(data.Gyro.y)) + Math.Abs(float.Parse(data.Gyro.z));
                        sensorminingstate.Text = "x:" + data.Gyro.x + " y:" + data.Gyro.y + " z:" + data.Gyro.z + " sum:" + sum;

                        switch (TmpData.SystemState.DollState)
                        {
                            case SystemStates.DollStates.Initializing:
                                break;
                            case SystemStates.DollStates.Initialized:
                                switch (TmpData.SystemState.Posture)
                                {
                                    case SystemStates.Postures.Move:
                                        if (sum < 10000)
                                        {
                                            TmpData.SystemState.Posture = SystemStates.Postures.Put;
                                        }
                                        else
                                        {
                                            /*if (DateTime.Now - TmpData.SystemState.ModifiedTimeOfPosture > new TimeSpan(0, 0, 5))
                                            {
                                                
                                            }*/
                                        }
                                        break;
                                    case SystemStates.Postures.Put:
                                        if (sum > 10000)
                                        {
                                            TmpData.SystemState.Posture = SystemStates.Postures.Move;
                                        }
                                        else
                                        {
                                            if (DateTime.Now - TmpData.SystemState.ModifiedTimeOfPosture > new TimeSpan(0, 0, 5))
                                            {
                                                //ここで待ってるよ～的な（待機状態に入る）
                                                TmpData.SystemState.DollState = SystemStates.DollStates.Waiting;
                                            }
                                        }
                                        break;
                                }
                                break;
                            case SystemStates.DollStates.Waiting:
                                switch (TmpData.SystemState.Posture)
                                {
                                    case SystemStates.Postures.Move:
                                        if (sum < 10000)
                                        {
                                            TmpData.SystemState.Posture = SystemStates.Postures.Put;
                                        }
                                        else
                                        {
                                            if (DateTime.Now - TmpData.SystemState.ModifiedTimeOfPosture > new TimeSpan(0, 0, 5))
                                            {
                                                //お帰り～！（ここから遊んでいる）
                                                TmpData.SystemState.DollState = SystemStates.DollStates.Moving;
                                            }
                                        }
                                        break;
                                    case SystemStates.Postures.Put:
                                        if (sum > 10000)
                                        {
                                            TmpData.SystemState.Posture = SystemStates.Postures.Move;
                                        }
                                        else
                                        {
                                            /*if (DateTime.Now - TmpData.SystemState.ModifiedTimeOfPosture > new TimeSpan(0, 0, 5))
                                            {
                                                
                                            }*/
                                        }
                                        break;
                                }
                                break;
                            case SystemStates.DollStates.Moving:
                                break;
                            case SystemStates.DollStates.Staying:
                                break;
                        }
                    });
                    await Task.Delay(700);
                }
            }
            catch (Exception ex)
            {
                var message = new MessageDialog("MiningSensors内でのエラー：" + ex.Message, "おや？なにかがおかしいようです。");
                //await message.ShowAsync();
                sensorminingstate.Text = ex.Message;
                await Task.Delay(5000);
                await MiningSensors();
            }
        }

        private async Task CheckServer()
        {
            string url = "http://mspjp-iot-hackathon.azurewebsites.net/api/nfc_tags";
            var client = new HttpClient();
            var res = await client.GetAsync(new Uri(url));
            if (res.IsSuccessStatusCode)
            {
                voiceminingstate.Text = "Now Loading...";
                var textObject = JsonConvert.DeserializeObject<ServerResponseJson>(res.Content.ToString());
                int reloadCount = 0;
                if (textObject.last_updated != TmpData.ServerData.last_updated)
                {
                    TmpData.ServerData = textObject;
                    var voiceClient = new VoiceClient();
                    await voiceClient.Init();
                    foreach (var text in textObject.tags)
                    {
                        var data = TmpData.VoiceDataCollection.Where(x => x.TagNumber == text.nfc_id).FirstOrDefault();
                        if (data == null)
                        {
                            var sound = await voiceClient.GetVoice(text.text);
                            var soundObject = new VoiceData(text.text, text.nfc_id, sound);
                            soundObject.Play();
                            TmpData.VoiceDataCollection.Add(soundObject);
                            reloadCount++;
                        }
                        else
                        {
                            if (data.VoiceText != text.text)
                            {
                                data.VoiceText = text.text;
                                var sound = await voiceClient.GetVoice(text.text);
                                data.VoiceBuffer = sound;
                                data.Play();
                                reloadCount++;
                            }
                        }
                    }
                    voiceminingstate.Text = "Reloaded " + reloadCount.ToString() + " items";
                    if (TmpData.SystemState.DollState == SystemStates.DollStates.Initializing)
                    {
                        //Initialize完了の音
                        TmpData.SystemState.DollState = SystemStates.DollStates.Waiting;
                    }
                }
                else
                {
                    voiceminingstate.Text = "Not Modified";
                }
            }
            else
            {
                throw new Exception("ステータスコードが成功ではありません：" + res.ReasonPhrase);
            }
        }
    }
}
