﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Devices.Enumeration;
using Windows.Devices.SerialCommunication;
using Windows.Storage.Streams;
using Windows.UI.Popups;

namespace RasPiApp.Utils
{
    public class SerialClient
    {
        public SerialClient()
        {

        }

        public async Task CaptureSensors(Action<string> fetchAction)
        {
            try
            {
                var dataReader = await OpenPort();
                if (dataReader != null)
                {
                    string result;
                    while (true)
                    {
                        result = await ReadAsync(dataReader);
                        if (!string.IsNullOrEmpty(result))
                        {
                            fetchAction(result);
                        }
                        await Task.Delay(700);
                    }
                }
                else
                {
                    throw new Exception("データリーダーが作れなかったよ。");
                }
            }
            catch (Exception ex)
            {
                var message = new MessageDialog("CaptureCencerからのメッセージ:" + ex.Message, "おや？何かがおかしいようです。");
                throw ex;
                //await message.ShowAsync();
                //await Task.Delay(2000);
                //await CaptureSensors(fetchAction);
            }
        }

        private async Task<string> ReadAsync(DataReader dataReaderObject)
        {
            Task<UInt32> loadAsyncTask;

            uint ReadBufferLength = 63;


            // Set InputStreamOptions to complete the asynchronous read operation when one or more bytes is available
            dataReaderObject.InputStreamOptions = InputStreamOptions.Partial;

            // Create a task object to wait for data on the serialPort.InputStream
            loadAsyncTask = dataReaderObject.LoadAsync(ReadBufferLength).AsTask();

            // Launch the task and wait
            UInt32 bytesRead = await loadAsyncTask;
            if (bytesRead > 0)
            {
                return dataReaderObject.ReadString(bytesRead);
            }
            return null;
        }

        private async Task<List<DeviceInformation>> ListAvailablePorts()
        {
            List<DeviceInformation> listOfDevices = new List<DeviceInformation>();

            try
            {
                string aqs = SerialDevice.GetDeviceSelector();
                var dis = await DeviceInformation.FindAllAsync(aqs);
                for (int i = 0; i < dis.Count; i++)
                {
                    listOfDevices.Add(dis[i]);
                }
                return listOfDevices;
            }
            catch (Exception ex)
            {
                var message = new MessageDialog("シリアルポートのリスト取得中にエラーが発生しました。:" + ex.Message, "おや？何かがおかしいようです。");
                throw ex;
                //await message.ShowAsync();
            }

            return null;
        }

        
        private async Task<DataReader> OpenPort()
        {
            var listOfDevices = await ListAvailablePorts();
            if (listOfDevices != null && listOfDevices.Count > 0)
            {
                DeviceInformation entry = (DeviceInformation)listOfDevices.First(x => x.Name == "STM32 STLink");
                var serialPort = await OpenPortByInfo(entry);

                var dataReaderObject = new DataReader(serialPort.InputStream);
                return dataReaderObject;
            }
            else
            {
                return null;
            }
        }
        private async Task<SerialDevice> OpenPortByInfo(DeviceInformation info)
        {
            var serialPort = await SerialDevice.FromIdAsync(info.Id);
            serialPort.WriteTimeout = TimeSpan.FromMilliseconds(1000);
            serialPort.ReadTimeout = TimeSpan.FromMilliseconds(1000);
            serialPort.BaudRate = 9600;
            serialPort.Parity = SerialParity.None;
            serialPort.StopBits = SerialStopBitCount.One;
            serialPort.DataBits = 8;
            serialPort.Handshake = SerialHandshake.None;
            return serialPort;
        }


    }
}
