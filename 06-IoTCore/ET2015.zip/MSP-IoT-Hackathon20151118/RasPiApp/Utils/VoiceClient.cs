﻿using OxfordTTS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Windows.Storage.Streams;
using Windows.UI.Popups;

namespace RasPiApp.Utils
{
    public class VoiceClient
    {
        Authentication auth { get; set; }

        public VoiceClient()
        {

        }

        public async Task Init()
        {
            auth = new Authentication("41b8bcd461f245f68a8616e843dcad53", "264cf396780a409b949befaaf1ac7cbb");
            try
            {
                await auth.Authorize();
            }
            catch (Exception ex)
            {
                var message = new MessageDialog("token取得できなかったよ...:" + ex.Message, "おや？なにかがおかしいようです");
                throw ex;
                //await message.ShowAsync();
            }
        }

        public async Task<IBuffer> GetVoice(string words)
        {
            string requestUri = "https://speech.platform.bing.com/synthesize";
            var token = auth.GetAccessToken();
            var cortana = new Synthesize(new Synthesize.InputOptions()
            {
                RequestUri = new Uri(requestUri),
                // Text to be spoken.
                //Text = "Hi, how are you doing?",
                Text = words,
                VoiceType = Gender.Female,
                //VoiceType = Gender.Male,
                // Refer to the documentation for complete list of supported locales.
                //Locale = "en-US",
                Locale = "ja-JP",
                // You can also customize the output voice. Refer to the documentation to view the different
                // voices that the TTS service can output.
                VoiceName = "Microsoft Server Speech Text to Speech Voice (ja-JP, Ayumi, Apollo)",
                //VoiceName = "Microsoft Server Speech Text to Speech Voice (ja-JP, Ichiro, Apollo)",
                // Service can return audio in different output format. 
                OutputFormat = AudioOutputFormat.Riff16Khz16BitMonoPcm,
                AuthorizationToken = "Bearer " + token.access_token,
            });

            return await cortana.Speak(CancellationToken.None);
        }
    }
}
